/*
@abstract(test for the tutorial on hidden Markov models )
@author(Nikolai Shokhirev <nikolai@shokhirev.com> <nikolai@u.arizona.edu>
        http://www.shokhirev.com/nikolai.html
        http://www.u.arizona.edu/~nikolai/
        http://www.chem.arizona.edu/~shokhirn/nikolai.html )
@created(2006.02.02)
�Nikolai V. Shokhirev, 2003-2006
 2006.02.24 - added PosteriorDecodingIdxs
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "fHMM.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  int N = 2;
  int M = 3;
  int K = 3;
/*
 http://en.wikipedia.org/wiki/Viterbi_algorithm
states = ('Rainy', 'Sunny')
observations = ('walk', 'shop', 'clean')

start_probability = {'Rainy': 0.6, 'Sunny': 0.4}

transition_probability = {
   'Rainy' : {'Rainy': 0.7, 'Sunny': 0.3},
   'Sunny' : {'Rainy': 0.4, 'Sunny': 0.6},
   }

emission_probability = {
   'Rainy' : {'walk': 0.1, 'shop': 0.4, 'clean': 0.5},
   'Sunny' : {'walk': 0.6, 'shop': 0.3, 'clean': 0.1},
   }
*/
  FArr1D P0(N);
  P0(1) = 0.6;
  P0(2) = 0.4;

  FArr2D A(N,N);
  A(1,1) = 0.7; A(1,2) = 0.3;
  A(2,1) = 0.4; A(2,2) = 0.6;

  FArr2D B(N,M);
  B(1,1) = 0.1; B(1,2) = 0.4; B(1,3) = 0.5;
  B(2,1) = 0.6; B(2,2) = 0.3; B(2,3) = 0.1;

  // ('walk', 'shop', 'clean')
  IArr1D Idxs(K);
  Idxs(1) = 1; Idxs(2) = 2; Idxs(3) = 3;

  HMM * hmm = new HMM(A, B, P0);
  Label1->Caption = "Forward: "+FloatToStr(hmm->GetProbabilityF(Idxs));
  Label2->Caption = "Backward: "+FloatToStr(hmm->GetProbabilityB(Idxs));

  IArr1D S = hmm->ViterbiStateIdxs(Idxs);
  AnsiString ss = "Viterbi States: ";
  for (int i = S.L1(); i <= S.H1(); i++)
    ss += IntToStr(S(i)) +",";
  Label3->Caption = ss;
  //Output:  ("Sunny", "Rainy", "Rainy")

  S = hmm->PosteriorDecodingIdxs(Idxs);
  ss = "Posterior States: ";
  for (int i = S.L1(); i <= S.H1(); i++)
    ss += IntToStr(S(i)) +",";
  Label5->Caption = ss;

  delete hmm;

}
//---------------------------------------------------------------------------

